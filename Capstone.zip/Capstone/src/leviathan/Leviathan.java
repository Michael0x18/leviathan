package leviathan;

/*
 *     __HEADER_GOES_HERE__
 */
public class Leviathan {
	
//	// Activate Program
//	public static void main(String[] Args) {
//		//To Do. 
//		//Assignment: Timothy Liu.                                           YA BOI TIM
//		//Set up the grid
//		//Just call the grid make method and it will handle it from there.
//	}
}
