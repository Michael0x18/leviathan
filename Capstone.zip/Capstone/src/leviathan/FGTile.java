//Timothy

package leviathan;

import java.awt.Image;

public abstract class FGTile extends Tile {

	public FGTile(int x, int y) {
		super(x, y);
		// TODO Auto-generated constructor stub
	}

	public FGTile(int x, int y, Image pic) {
		super(x, y, pic);
	}
	// For: Timothy Liu
	// Make draw method and define method boolean in(Monster m)
	// also boolean in(Player p)
	// public abstract performAction
	// declare fields private or protected
	// call super

}
