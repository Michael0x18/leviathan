package leviathan;

public class MOVESTATE {
	public static final int WAIT = 0, CHASE = 1, PATROL = 2;
}
