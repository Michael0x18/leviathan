package leviathan;

public abstract class FluidTile extends FGTile{

	public FluidTile(int x, int y) {
		super(x, y);
		// TODO Auto-generated constructor stub
	}
	//Timothy Liu
	
	//Like Water or lava. you figure this one out.
}
