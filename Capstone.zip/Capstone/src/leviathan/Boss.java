//Michael

package leviathan;

public interface Boss {
	
	
}
