package leviathan;

import java.awt.Graphics;

import javax.swing.JPanel;

public class LeviathanPanel extends JPanel {
	
	private Tile tl = new GroundTile(0,0);
	private Tile[][] tiles = {{tl.c(),tl.c(),tl.c(),tl.c(),tl.c()},{tl.c(),tl.c(),tl.c(),tl.c(),tl.c()},
			{tl.c(),tl.c(),tl.c(),tl.c(),tl.c()},{tl.c(),tl.c(),tl.c(),tl.c(),tl.c()},{tl.c(),tl.c(),tl.c(),tl.c(),tl.c()}};
	
	/**
	 * 
	 */
	
	public void setTiles(Tile[][] t) {
		this.tiles = t.clone();
	}
	
	private static final long serialVersionUID = -4593569340321448146L;

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		for (Tile[] a : this.tiles) {
			for (Tile t : a) {
				t.draw(g);
				//System.out.println("Drawn "+t.toString());
				//System.out.println(a[0]);
			}
		}
		
	}
	
	

}
