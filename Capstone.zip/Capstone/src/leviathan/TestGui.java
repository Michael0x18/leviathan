package leviathan;

import java.awt.*;
import javax.swing.*;

public class TestGui extends JPanel {
//
//	public static void main(String[] args) {
//		JFrame window = new JFrame("Test of GUI commands");
//		window.setBounds(-10,-10,500,500);
//		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//		window.setVisible(true);
//		
//		TestGui panel = new TestGui();
//		//panel.setBackground(Color.WHITE);
//		Container c = window.getContentPane();
//		c.add(panel);
//		
//		window.repaint();
//	}

	public void paintComponent(Graphics g){
		super.paintComponent(g);
		 
	//	Monster monster1 = new Monster();
	//	monster1.draw(g);
	//	g.drawString("sldkf", 10, 10);
		
	}
}
