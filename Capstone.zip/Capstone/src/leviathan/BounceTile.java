//Timothy

package leviathan;

import java.awt.Image;

public class BounceTile extends Tile{

	public BounceTile(int x, int y) {
		super(x, y);
		// TODO Auto-generated constructor stub
	}
	//Timothy Liu
	// Makes player jump automatically when player steps on it.
	// Use "player.jump();"
	// Otherwise, same as normal tile.

	public BounceTile(int i, int j, Image pic) {
		super(i,j,pic);
	}

	@Override
	public void act() {
		// TODO Auto-generated method stub
		
	}
	
	public BounceTile c(){
		return new BounceTile(0,0,this.getSprite());
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getType() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
