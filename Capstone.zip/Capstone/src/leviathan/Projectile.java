package leviathan;

//Generic Projectile
//Used to handle shots of all types
//Fields are sprite, start position, damage, and lifetime in ticks


public class Projectile {
	int life = 0x0;
	
	public Projectile(int x, int y,int lifetime) {
		//setup function
	}

}
