package leviathan;

import java.awt.Graphics;
import java.awt.Graphics.*;
import java.awt.Image;
import java.awt.event.*;
import javax.swing.*;

//Michael Ferolito                    Last edited: Apr 10 7:27:12 PM
//Superclass for all monsters.               NOTE: AffineTransform throws error on rotational coordinate transformation. Implement
//                                                  .rotate(degrees) by using (x,y)->(x,-y) type coordinates. Undo XY translation from
//                                                 center of rotation. Call AffineTransform. Redo XY translate.

//                                           NOTE: Stats may have to be factored out into another class; Almost the same used in Player.
//												   Player needs slightly more, so: PlayerStat-->ClientStat  ?

//											NOTE: NEED TO TEST SUPERCLASS METHOD INTERGRATION WITH SUBCLASS OVERWRITES!!

public abstract class Monster {
	private Image sprite;
	private CoordinateSystem coords;

	private int HP = 0x1;
	private int def = 0x0;
	private int spd = 0x1;
	private int att = 0x0;
	private int vit = 0x1;
	private Image deathImage = null;
	private int health = 0x1;

	public Monster() {
		this.sprite = new ImageIcon("BlankSprite.png").getImage();
		this.coords = new CoordinateSystem(10, 10, this.sprite);
	}
	
	public boolean takeDamage(int amount) {
		this.HP -= amount;
		return this.HP<0 ? this.die() : false;
	}

	public Monster(int x, int y, String SpritePath) {
		this.sprite = new ImageIcon(SpritePath).getImage();
		this.coords = new CoordinateSystem(x, y, this.sprite);
	}

	public int[] getCoords() {
		return this.coords.get();
	}

	public void draw(Graphics g) {
		coords.drawImage(g, this.sprite);
		// System.out.println(this.sprite);
	}
	
	public abstract boolean makeRangedAttack();
	public abstract boolean makeMeleeAttack();
	public abstract boolean die();
	

	public int getHP() {
		return HP;
	}

	public void setHP(int hP) {
		HP = hP;
	}

	public int getDef() {
		return def;
	}

	public void setDef(int def) {
		this.def = def;
	}

	public int getSpd() {
		return spd;
	}

	public void setSpd(int spd) {
		this.spd = spd;
	}

	public void set(int[] a) {
		this.HP = a[0];
		this.def = a[1];
		this.spd = a[2];
		this.setAtt(a[3]);
		this.setVit(a[4]);
	}
	
	public void get(int[] a) {
		int[]array = {0,0,0,0,0};
		a[0] = this.HP;
		a[1] = this.def;
		a[2] = this.spd;
		a[3] = this.att;
		a[4] = this.vit;
		
	}

	public int getAtt() {
		return att;
	}

	public void setAtt(int att) {
		this.att = att;
	}

	public int getVit() {
		return vit;
	}

	public void setVit(int vit) {
		this.vit = vit;
	}

	public Image getDeathImage() {
		return deathImage;
	}

	public void setDeathImage(Image deathImage) {
		this.deathImage = deathImage;
	}

	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		this.health = health;
	}
	

}
