package leviathan;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
//Assignment: Joshua Han
//Stores a 256 by 256 array of tile objects. MAKE SURE THE ARRAY TYPE IS "Tile", not FGTile; it will have to hold both!
//Make a grid.translate method that calls the translate methods of all tiles in its grid. OR: make it change the viewpoint of the screen viewing window.

public class Grid extends JFrame implements ActionListener, KeyListener{

	/**
	 * boi
	 */
	
	private int fallCount = 0;
	private static String[]highScores = {"","","","",""};
	private int bX = 0, bY = 0;
	private static final long serialVersionUID = 1L;
	private Timer t = new Timer(10, this);
	private LeviathanPanel panel = new LeviathanPanel();
	private TextArea focus = new TextArea();
	private GroundTile tl = new GroundTile(0,0);
	private Tile[][] tiles = {{tl.c(),tl.c(),tl.c(),tl.c(),tl.c()},{tl.c(),tl.c(),tl.c(),tl.c(),tl.c()},
			{tl.c(),tl.c(),tl.c(),tl.c(),tl.c()},{tl.c(),tl.c(),tl.c(),tl.c(),tl.c()},{tl.c(),tl.c(),tl.c(),tl.c(),tl.c()}};
	private Image stone = new ImageIcon("Stone.png").getImage();
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource().equals(t)) {
			focus.requestFocus();
			
		}
		repaint();
	}
	
	public Grid() {
		super("Leviathan");
		this.setVisible(true);
		this.setBounds(0,0,800,600);
		this.setBackground(Color.BLUE);
		panel.addKeyListener(this);
		//panel.setBackground(Color.YELLOW);
		this.init();
		panel.setBounds(0, 0, 800, 600);
		focus.addKeyListener(this);
		this.add(focus);
		focus.setVisible(true);
		this.add(panel);
		this.setResizable(false);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setDefaultLookAndFeel(true);
		t.start();
		repaint();
		//System.out.println(this.tiles[1][1]);
		//System.out.println(this.tl);
		
	}
	
	private void setDefaultLookAndFeel(boolean b) {
		// TODO Auto-generated method stub
		
	}
	
	public static void print() {
		
	}

	public void init() {
		//sets up the grid thing:
		//you know, like the :
		//Grid window = new Grid();
		//window.setBounds(And you put in the values);
		//SetdefaultCloseOperationtoEXIT_ONCLOSE
		//and set it to be seen
		//Actually make it non-resizable too.
		//see what else you need.
		//dontmind the spelling errors.
		int a = -1;
		
		
		for (Tile[] xindex : this.tiles) {
			a++;
			int b = -1;
			for (Tile t : xindex) {
				//System.out.println("   "+a+" "+(b+1));
				b++;
				Tile l = new GroundTile(a*16,b*16,this.stone);
				t = l.c();
				//System.out.println(""+t.getX()+" "+t.getY());
				t.shift(16*a, 16*b);
				//System.out.println(""+t.getX()+" "+t.getY());
				this.tiles[a][b]=t;
			}
			
		}
		//System.out.println(this.tiles.length);
		panel.setTiles(this.tiles);
		//System.out.println(this.tiles[1][1]);
	}

	@Override
	public void keyPressed(KeyEvent arg0) {
		//int a = arg0.getKeyCode();
		//System.out.println(a);
		//System.out.println("key pressed");
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		//System.out.println("released");
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		System.out.println(e.getKeyChar());
		
	}
	
	public void paintComponent(Graphics g) {
		super.paintComponents(g);
		g.setColor(Color.BLUE);
		g.drawString("Leviathan", 100, 100);
		//System.out.println("PAINT");
		
	}
	
	public static void main(String[] args) {
		Grid grid = new Grid();
		//grid.repaint();
	}

}