package leviathan;

public abstract class TrapTile extends Tile{

	public TrapTile(int x, int y) {
		super(x, y);
	}
	//Timothy Liu
}
